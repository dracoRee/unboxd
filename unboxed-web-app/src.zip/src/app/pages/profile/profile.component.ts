import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { UserService, UserProfile, UserListing } from '../../services/user.service';
import { AuthService } from '../../services/auth.service';
import { SupabaseService } from '../../services/supabase.service';
import { VouchService } from '../../services/vouch.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css',
})

export class ProfileComponent implements OnInit {
  profile?: UserProfile;
  isOwnProfile = false;
  isEditing = false;
  isSaving = false;
  editData = { bio: '', profilePicture: '' };
  selectedFile: File | null = null;
  userListings: UserListing[] = [];
  activeTab: 'collection' | 'activity' | 'listings' = 'listings';

  constructor(
    private route: ActivatedRoute,
    private userService: UserService,
    public authService: AuthService,
    private supabaseService: SupabaseService,
    private vouchService: VouchService
  ) {}

  ngOnInit() {
    this.route.params.subscribe(params => {
      const id = params['id'];
      if (id) {
        // Wait for auth to be ready before loading profile
        const backendUser = this.authService.backendUser();
        if (backendUser?.id) {
          this.loadProfile(parseInt(id));
        } else {
          // If auth not ready, wait a bit and retry
          setTimeout(() => {
            this.loadProfile(parseInt(id));
          }, 500);
        }
      }
    });
  }

  loadProfile(id: number) {
    const backendUser = this.authService.backendUser();
    const currentUserId = backendUser?.id;
    
    this.userService.getProfile(id, currentUserId).subscribe(profile => {
      this.profile = profile;
      // Ensure we have current user ID for comparison
      const freshBackendUser = this.authService.backendUser();
      const freshCurrentUserId = freshBackendUser?.id;
      this.isOwnProfile = freshCurrentUserId !== undefined && freshCurrentUserId === profile.id;
      this.editData = { 
        bio: profile.bio || '', 
        profilePicture: profile.profilePicture || '' 
      };
      this.loadListings(id);
    });
  }

  loadListings(userId: number) {
    this.userService.getUserListings(userId).subscribe(listings => {
      this.userListings = listings;
    });
  }

  toggleUserVouch() {
    const currentUser = this.authService.backendUser();
    if (!currentUser || !this.profile || this.isOwnProfile) return;

    // Optimistic Update
    this.profile.hasVouched = !this.profile.hasVouched;
    this.profile.vouchCount = (this.profile.vouchCount || 0) + (this.profile.hasVouched ? 1 : -1);

    this.vouchService.toggleVouch('USER', this.profile.id, this.profile.hasVouched).subscribe({
      next: (res) => {
        if (this.profile) this.profile.vouchCount = res.vouchCount;
      },
      error: (err) => {
        console.error('Failed to toggle user vouch', err);
        // Revert on failure
        if (this.profile) {
          this.profile.hasVouched = !this.profile.hasVouched;
          this.profile.vouchCount = (this.profile.vouchCount || 0) + (this.profile.hasVouched ? 1 : -1);
        }
      }
    });
  }

  toggleEdit() {
    this.isEditing = !this.isEditing;
    if (!this.isEditing) {
      this.selectedFile = null;
    }
  }

  triggerFileInput() {
    const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;
    if (fileInput) fileInput.click();
  }

  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
      this.isEditing = true; // Auto-enter edit mode when file selected
    }
  }

  async saveProfile() {
    if (!this.profile) return;
    this.isSaving = true;

    try {
      let profilePicture = this.editData.profilePicture;

      if (this.selectedFile) {
        const fileExt = this.selectedFile.name.split('.').pop();
        const fileName = `profile_${this.profile.id}_${Math.random().toString(36).substring(2)}.${fileExt}`;
        const filePath = `profiles/${fileName}`;
        
        profilePicture = await this.supabaseService.uploadFile(filePath, this.selectedFile);
      }

      const updatePayload = {
        ...this.editData,
        profilePicture
      };

      this.userService.updateProfile(this.profile.id, updatePayload).subscribe({
        next: (updated) => {
          this.profile = { ...this.profile!, ...updated };
          this.isEditing = false;
          this.isSaving = false;
          this.selectedFile = null;
        },
        error: (err) => {
          console.error('Failed to update profile', err);
          this.isSaving = false;
          alert('Failed to save profile. Please try again.');
        }
      });
    } catch (err) {
      console.error('Error uploading profile picture', err);
      this.isSaving = false;
      alert('Error uploading image. Please check your connection.');
    }
  }

  toggleFollow() {
    if (!this.profile) return;
    const currentUserId = this.authService.backendUser()?.id;
    
    // Prevent following yourself
    if (!currentUserId || currentUserId === this.profile.id) {
      console.warn('Cannot follow yourself');
      return;
    }
    
    if (this.profile.isFollowing) {
      this.userService.unfollowUser(currentUserId, this.profile.id).subscribe(() => {
        if (this.profile) {
          this.profile.isFollowing = false;
          this.profile._count.User_B--;
        }
      });
    } else {
      this.userService.followUser(currentUserId, this.profile.id).subscribe(() => {
        if (this.profile) {
          this.profile.isFollowing = true;
          this.profile._count.User_B++;
        }
      });
    }
  }

  logout() {
    this.authService.logout();
    // Optionally, navigate to login or home page after logout
    window.location.href = '/login';
  }
}
